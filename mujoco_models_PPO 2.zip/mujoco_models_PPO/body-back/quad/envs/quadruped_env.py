import gym
from gym import error, spaces, utils
from gym.utils import seeding
import numpy as np
import os
import PIL.Image as pilimg
import mujoco as mj
from mujoco.glfw import glfw
import numpy as np
import math
import pylab
import random
import gc

xml_path = 'body-back.xml'
print_camera_config = 0 
reward = 0
button_left = False
button_middle = False
button_right = False
lastx = 0
lasty = 0
total_return = 0
score_avg = 0
scores, episodes = [], []
ka = 50
kb = 0.1
kc = 1
kd = 1
_overlay = {}
episode = 0

def add_overlay(gridpos, text1, text2):
    if gridpos not in _overlay:
        _overlay[gridpos] = ["", ""]
    _overlay[gridpos][0] += text1 + "\n"
    _overlay[gridpos][1] += text2 + "\n"

def create_overlay(model,data):
    topleft = mj.mjtGridPos.mjGRID_TOPLEFT
    topright = mj.mjtGridPos.mjGRID_TOPRIGHT
    bottomleft = mj.mjtGridPos.mjGRID_BOTTOMLEFT
    bottomright = mj.mjtGridPos.mjGRID_BOTTOMRIGHT
    global episode
    global reward

    add_overlay(bottomleft, "episode", str(episode) ,)
    add_overlay(bottomleft, "Time", '%.2f' % data.time,)
    add_overlay(bottomleft, "reward", '%.2f' % total_return,)
    add_overlay(bottomleft, "x", '%.2f' % data.qpos[0],)
    add_overlay(bottomleft, "y", '%.2f' % data.qpos[1],)

def init_controller(model,data):
    pass

def controller(model, data):
    pass

def keyboard(window, key, scancode, act, mods):
    if act == glfw.PRESS and key == glfw.KEY_BACKSPACE:
        mj.mj_resetData(model, data)
        mj.mj_forward(model, data)

def mouse_button(window, button, act, mods):
    global button_left
    global button_middle
    global button_right

    button_left = (glfw.get_mouse_button(
        window, glfw.MOUSE_BUTTON_LEFT) == glfw.PRESS)
    button_middle = (glfw.get_mouse_button(
        window, glfw.MOUSE_BUTTON_MIDDLE) == glfw.PRESS)
    button_right = (glfw.get_mouse_button(
        window, glfw.MOUSE_BUTTON_RIGHT) == glfw.PRESS)
    glfw.get_cursor_pos(window)

def mouse_move(window, xpos, ypos):
    global lastx
    global lasty
    global button_left
    global button_middle
    global button_right
    dx = xpos - lastx
    dy = ypos - lasty
    lastx = xpos
    lasty = ypos

    if (not button_left) and (not button_middle) and (not button_right):
        return

    width, height = glfw.get_window_size(window)

    PRESS_LEFT_SHIFT = glfw.get_key(
        window, glfw.KEY_LEFT_SHIFT) == glfw.PRESS
    PRESS_RIGHT_SHIFT = glfw.get_key(
        window, glfw.KEY_RIGHT_SHIFT) == glfw.PRESS
    mod_shift = (PRESS_LEFT_SHIFT or PRESS_RIGHT_SHIFT)

    if button_right:
        if mod_shift:
            action = mj.mjtMouse.mjMOUSE_MOVE_H
        else:
            action = mj.mjtMouse.mjMOUSE_MOVE_V
    elif button_left:
        if mod_shift:
            action = mj.mjtMouse.mjMOUSE_ROTATE_H
        else:
            action = mj.mjtMouse.mjMOUSE_ROTATE_V
    else:
        action = mj.mjtMouse.mjMOUSE_ZOOM

    mj.mjv_moveCamera(model, action, dx/height,
                      dy/height, scene, cam)

def scroll(window, xoffset, yoffset):
    action = mj.mjtMouse.mjMOUSE_ZOOM
    mj.mjv_moveCamera(model, action, 0.0, -0.05 *
                      yoffset, scene, cam)

dirname = os.path.dirname(__file__)
abspath = os.path.join(dirname + "/" + xml_path)
xml_path = abspath

model = mj.MjModel.from_xml_path(xml_path)  
data = mj.MjData(model)
cam = mj.MjvCamera()                    
opt = mj.MjvOption()                    

init_controller(model,data)

mj.set_mjcb_control(controller)

glfw.init()
window = glfw.create_window(1200, 900, "quadruped", None, None)
glfw.make_context_current(window)
glfw.swap_interval(1)
mj.mjv_defaultCamera(cam)
mj.mjv_defaultOption(opt)
glfw.set_key_callback(window, keyboard)
glfw.set_cursor_pos_callback(window, mouse_move)
glfw.set_mouse_button_callback(window, mouse_button)
glfw.set_scroll_callback(window, scroll)
scene = mj.MjvScene(model, maxgeom=10000)
context = mj.MjrContext(model, mj.mjtFontScale.mjFONTSCALE_150.value)
cam.azimuth = 90 ; cam.elevation = -3 ; cam.distance =  3
cam.lookat =np.array([ 0.0 , -5 , 2.5 ])

class Quadruped_robot(gym.Env):

    def __init__(self):
        self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(12, ), dtype="float32")
        self.observation_space = spaces.Box(low=-10**5, high=10**5, shape=(58,), dtype="float32")
        self.done = False
        self.rend = False
        self.episode = 0
        self.train = False

    def step(self, action):
        global reward
        global total_return
        global score_avg
        global episode
        episode = self.episode
        if self.rend == True:
            create_overlay(model,data)
            viewport_width, viewport_height = glfw.get_framebuffer_size(window)
            viewport = mj.MjrRect(0, 0, viewport_width, viewport_height)
            mj.mjv_updateScene(model, data, opt, None, cam,
            mj.mjtCatBit.mjCAT_ALL.value, scene)
            mj.mjr_render(viewport, scene, context)
            for gridpos, [t1, t2] in _overlay.items():
                mj.mjr_overlay(
                    mj.mjtFontScale.mjFONTSCALE_150, gridpos, viewport, t1, t2, context)
            glfw.swap_buffers(window)
            glfw.poll_events()
        for i in range(12):
            data.ctrl[i] = action[i] * 2
        time_prev = data.time
        while (data.time - time_prev < 1.0/60.0):
            mj.mj_step(model, data)
        state1 = [data.qpos[i] for i in range(6, 18)]
        state2 = [data.sensordata[i] for i in range(28)]
        state3 = [data.qvel[i] for i in range(18)]
        n_state = state1 + state2 + state3
        '''
        ka = 1
        kb = 90
        kc = 0.5
        kd = 6
        target_theta = math.atan2(target_y, target_x)
        present_theta = math.atan2(data.sensordata[10], data.sensordata[9])
        energy = 0
        for i in range(6, 18):
            energy += action[i - 6] * data.qvel[i]
        velocity = data.qvel[0] * data.sensordata[9]  + data.qvel[1] * data.sensordata[10]
        z = data.sensordata[2]
        reward = -ka * abs(target_theta - present_theta) + kb * velocity - kc * energy + kd * z
        reward = kb * velocity - kc * energy + kd * z'''
        target_vel = 2
        c = [0] * 4
        re = 0
        rslip = 0
        for i in range(6, 18):
            re += abs(action[i - 6] * data.qvel[i])
        re = re * kb
        velocity = data.qvel[0] * data.sensordata[9]  + data.qvel[1] * data.sensordata[10]
        rvel = ka * math.exp(-((target_vel - velocity)**2))
        for i in range(4):
            if data.sensordata[i + 12] >= 0.1:
                c[i] = 1
            else:
                c[i] = 0
        for i in range(4):
            rslip += kc * c[i] * ((data.sensordata[16 + i * 3])**2 + (data.sensordata[17 + i * 3])**2)
        rbase = kd * ((data.qvel[3])**2 + (data.qvel[4])**2)
        reward = rvel - re - rslip - rbase
        total_return  = total_return + reward
        if data.time >= 80:
            self.done = True
            self.plot(self.train) 
            self.episode = self.episode + 1      
        elif data.sensordata[2] <= 0.2:
            reward = reward - 1000000
            total_return = total_return + reward
            self.done = True
            self.plot(self.train) 
            self.episode = self.episode + 1
        else:
            self.done = False
        _overlay.clear()
        return n_state, reward, self.done, {}

    def reset(self):
        global total_return
        total_return = 0
        gc.collect()
        mj.mj_resetData(model, data)
        mj.mj_forward(model, data)
        for i in range(12):
            data.ctrl[i] = 0
        state1 = [data.qpos[i] for i in range(6, 18)]
        state2 = [data.sensordata[i] for i in range(28)]
        state3 = [data.qvel[i] for i in range(18)]
        state = state1 + state2 + state3
        return state
    
    def render(self):
        create_overlay(model,data)
        viewport_width, viewport_height = glfw.get_framebuffer_size(window)
        viewport = mj.MjrRect(0, 0, viewport_width, viewport_height)
        mj.mjv_updateScene(model, data, opt, None, cam,
        mj.mjtCatBit.mjCAT_ALL.value, scene)
        mj.mjr_render(viewport, scene, context)
        for gridpos, [t1, t2] in _overlay.items():
            mj.mjr_overlay(mj.mjtFontScale.mjFONTSCALE_150, gridpos, viewport, t1, t2, context)
            glfw.swap_buffers(window)
            glfw.poll_events()

    def plot(self, enable):
        if enable == True:
            global score_avg
            global episode
            global total_return
            score_avg = 0.9 * score_avg + 0.1 * total_return if episode != 0 else total_return 
            scores.append(score_avg)
            episodes.append(self.episode)
            pylab.plot(episodes, scores, 'b')
            pylab.xlabel("episode")
            pylab.ylabel("average score")
            pylab.savefig("DQN_Pen.png") 