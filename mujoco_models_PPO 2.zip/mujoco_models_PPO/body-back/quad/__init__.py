from gym.envs.registration import register

register(
    id='quadruped_robot-v0',
    entry_point='quad.envs:Quadruped_robot',
)